import React from 'react';

export default function Main() {
  return <div className="text-blue-600 text-3xl font-bold underline">빌드가 성공적1234</div>;
}
