import React from 'react';
import Gallery from './Gallery';

export default function GalleryList() {
  return (
    <div className="gallerylist">
      <Gallery />
      <Gallery />
      <Gallery />
      <Gallery />
      <Gallery />
      <Gallery />
      <Gallery />
      <Gallery />
    </div>
  );
}
